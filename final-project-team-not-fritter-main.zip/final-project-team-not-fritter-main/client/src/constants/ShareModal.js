export const BASE_URL = "https://e-template.herokuapp.com";
