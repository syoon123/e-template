export const TEMPLATE_REFRESH_INTERVAL = 1000 * 60; // 1 minute
