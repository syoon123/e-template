export const COOKIE_NAME = "e-template";
export const NAV_PLUS_ICON_SIZE = 25;
export const NAV_PROFILE_ICON_SIZE = 25;
